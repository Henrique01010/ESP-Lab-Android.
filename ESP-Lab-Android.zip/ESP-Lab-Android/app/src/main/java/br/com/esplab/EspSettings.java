package br.com.esplab;

import android.content.Context;
import android.content.SharedPreferences;

/** Options shared by the editor, embedded preview and overlay. */
public final class EspSettings {
    public static final String PREFS = "esp_lab_settings";
    public static final String BOX = "box";
    public static final String NAME = "name";
    public static final String DISTANCE = "distance";
    public static final String SKELETON = "skeleton";
    public static final String TRACER = "tracer";
    public static final String HEALTH = "health";
    public static final String CROSSHAIR = "crosshair";
    public static final String OPACITY = "opacity";
    public static final String THICKNESS = "thickness";

    private EspSettings() {}
    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
    public static boolean read(SharedPreferences p, String key) {
        return p.getBoolean(key, !SKELETON.equals(key) && !TRACER.equals(key));
    }
}
