package br.com.esplab;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Modern control panel for the standalone fictional ESP renderer. */
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10,16,32);
    private static final int CARD = Color.rgb(20,29,47);
    private static final int CARD2 = Color.rgb(24,35,54);
    private static final int MINT = Color.rgb(66,228,191);
    private static final int WHITE = Color.rgb(242,246,250);
    private static final int MUTED = Color.rgb(156,171,192);

    private final String[] optionKeys = {
            EspSettings.BOX, EspSettings.NAME, EspSettings.DISTANCE,
            EspSettings.SKELETON, EspSettings.TRACER,
            EspSettings.HEALTH, EspSettings.CROSSHAIR
    };
    private SharedPreferences prefs;
    private TextView status;
    private EspCanvasView preview;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = EspSettings.get(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(24),dp(20),dp(30));
        scroll.addView(root);
        setContentView(scroll);

        // Product identity
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◎", 33, MINT, true);
        brand.addView(logo);
        LinearLayout brandName = vertical();
        brandName.setPadding(dp(10),0,0,0);
        TextView name = text("ESP LAB", 15, WHITE, true);
        name.setLetterSpacing(.16f);
        brandName.addView(name);
        brandName.addView(text("ANDROID  •  VERSÃO DE TESTE", 9, MUTED, true));
        brand.addView(brandName);
        root.addView(brand);
        topSpace(root,25);
        root.addView(text("Seu painel de\nvisualização", 28, WHITE, true));
        topSpace(root,6);
        root.addView(text("Personalize o HUD e veja os efeitos em tempo real. Sem root, sem acesso a dados do Oxide.", 13, MUTED, false));
        topSpace(root,20);

        // Synthetic ESP preview
        LinearLayout previewCard = vertical();
        previewCard.setPadding(dp(12),dp(12),dp(12),dp(12));
        previewCard.setBackground(round(CARD, 19, 0));
        rowBetween(previewCard, "PRÉVIA EM TEMPO REAL", "●  DEMO", 11, 10);
        topSpace(previewCard,10);
        FrameLayout previewFrame = new FrameLayout(this);
        GradientDrawable clipShape = round(CARD2, 14, 0);
        previewFrame.setBackground(clipShape);
        previewFrame.setClipToOutline(true);
        preview = new EspCanvasView(this, false);
        previewFrame.addView(preview, new FrameLayout.LayoutParams(-1,-1));
        previewCard.addView(previewFrame, new LinearLayout.LayoutParams(-1,dp(230)));
        topSpace(previewCard,9);
        previewCard.addView(text("Os três alvos acima são simulados para testar o desenho.", 11, MUTED, false));
        root.addView(previewCard);
        topSpace(root,17);

        // Overlay controls
        LinearLayout overlayCard = vertical();
        overlayCard.setPadding(dp(16),dp(17),dp(16),dp(18));
        overlayCard.setBackground(round(CARD, 19, 0));
        rowBetween(overlayCard, "SOBREPOSIÇÃO ANDROID", "SEM ROOT", 12, 10);
        topSpace(overlayCard,10);
        status = text("●  Desativada", 13, MUTED, true);
        overlayCard.addView(status);
        topSpace(overlayCard,14);
        TextView start = actionButton("ATIVAR SOBREPOSIÇÃO DE TESTE", true);
        start.setOnClickListener(v -> startOverlay());
        overlayCard.addView(start, new LinearLayout.LayoutParams(-1,dp(50)));
        topSpace(overlayCard,9);
        TextView stop = actionButton("DESATIVAR SOBREPOSIÇÃO", false);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            updateStatus(false);
            Toast.makeText(this, "Sobreposição desativada", Toast.LENGTH_SHORT).show();
        });
        overlayCard.addView(stop, new LinearLayout.LayoutParams(-1,dp(46)));
        topSpace(overlayCard,8);
        overlayCard.addView(text("Os desenhos ficam sobre outros aplicativos, mas não seguem jogadores reais.", 11, MUTED, false));
        root.addView(overlayCard);
        topSpace(root,24);

        // Settings toggles
        section(root,"MÓDULOS DE EXIBIÇÃO","Ative ou desative as camadas da prévia");
        LinearLayout optionsCard = vertical();
        optionsCard.setBackground(round(CARD,19,0));
        optionsCard.setPadding(dp(13),dp(3),dp(13),dp(3));
        addOption(optionsCard, EspSettings.BOX, "Box ESP", "Caixas ao redor dos alvos simulados", true);
        addOption(optionsCard, EspSettings.NAME, "Nomes", "Etiqueta de identificação", true);
        addOption(optionsCard, EspSettings.DISTANCE, "Distância", "Distâncias fictícias em metros", true);
        addOption(optionsCard, EspSettings.SKELETON, "Esqueleto", "Linhas de referência de articulações", true);
        addOption(optionsCard, EspSettings.TRACER, "Linhas ESP", "Linhas partindo da base da tela", true);
        addOption(optionsCard, EspSettings.HEALTH, "Barra de vida", "Exibe indicador ilustrativo", true);
        addOption(optionsCard, EspSettings.CROSSHAIR, "Mira central", "Marcador fixo no centro da tela", false);
        root.addView(optionsCard);
        topSpace(root,24);

        section(root,"AJUSTES VISUAIS","Personalize as linhas e a transparência");
        LinearLayout tuneCard = vertical();
        tuneCard.setPadding(dp(16),dp(16),dp(16),dp(16));
        tuneCard.setBackground(round(CARD,19,0));
        addSeek(tuneCard,"OPACIDADE",EspSettings.OPACITY,30,100,90,"%");
        topSpace(tuneCard,14);
        addSeek(tuneCard,"ESPESSURA DAS LINHAS",EspSettings.THICKNESS,1,6,2,"dp");
        root.addView(tuneCard);
        topSpace(root,20);

        LinearLayout note = vertical();
        note.setPadding(dp(14),dp(14),dp(14),dp(14));
        note.setBackground(round(Color.rgb(20,40,48),14,Color.rgb(37,87,85)));
        note.addView(text("ℹ  PROJETO INDEPENDENTE", 11, MINT, true));
        topSpace(note,7);
        note.addView(text("Este protótipo demonstra a interface e o desenho de um ESP. Não inclui loader, aimbot, injeção, leitura de memória, bypass de anticheat ou integração com jogos.", 12, WHITE, false));
        root.addView(note);
        topSpace(root,18);
        TextView footer = text("ESP LAB  •  BUILD 1.0.0  •  ARM64 / ANDROID", 10, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
        updateStatus(OverlayService.running);
    }

    private void rowBetween(LinearLayout target, String left, String right, int s1, int s2) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = text(left,s1,WHITE,true);
        row.addView(a,new LinearLayout.LayoutParams(0,-2,1));
        TextView b = text(right,s2,MINT,true);
        row.addView(b);
        target.addView(row);
    }

    private void section(LinearLayout root, String title, String subtitle) {
        TextView txt = text(title,13,WHITE,true);
        txt.setLetterSpacing(.07f);
        root.addView(txt);
        topSpace(root,4);
        root.addView(text(subtitle,12,MUTED,false));
        topSpace(root,12);
    }

    private void addOption(LinearLayout card, String key, String title, String subtitle, boolean divider) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(3),dp(13),dp(2),dp(13));
        LinearLayout info = vertical();
        info.addView(text(title,14,WHITE,true));
        topSpace(info,3);
        info.addView(text(subtitle,11,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Switch toggle = new Switch(this);
        toggle.setContentDescription("Ativar " + title);
        toggle.setShowText(false);
        int[][] states = new int[][] { new int[] { android.R.attr.state_checked }, new int[] {} };
        toggle.setThumbTintList(new ColorStateList(states, new int[] { MINT, Color.rgb(116,127,145) }));
        toggle.setTrackTintList(new ColorStateList(states, new int[] { Color.rgb(33,107,94), Color.rgb(65,77,96) }));
        toggle.setChecked(EspSettings.read(prefs,key));
        toggle.setOnCheckedChangeListener((button,checked)->prefs.edit().putBoolean(key,checked).apply());
        row.addView(toggle);
        card.addView(row);
        if (divider) {
            View line = new View(this);
            line.setBackgroundColor(Color.rgb(38,50,67));
            card.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }

    private void addSeek(LinearLayout panel, String title, String key, int min, int max, int defaultValue, String unit) {
        LinearLayout header = new LinearLayout(this);
        TextView label = text(title,12,WHITE,true);
        header.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        TextView value = text(prefs.getInt(key,defaultValue)+unit,12,MINT,true);
        header.addView(value);
        panel.addView(header);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max-min);
        seek.setProgress(prefs.getInt(key,defaultValue)-min);
        seek.setProgressTintList(ColorStateList.valueOf(MINT));
        seek.setThumbTintList(ColorStateList.valueOf(MINT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = min+progress;
                value.setText(v+unit);
                if (fromUser) prefs.edit().putInt(key,v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        panel.addView(seek,new LinearLayout.LayoutParams(-1,dp(42)));
    }

    private TextView actionButton(String title, boolean primary) {
        TextView b = text(title,12,primary ? BG : MINT,true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(.04f);
        b.setBackground(round(primary ? MINT : CARD2,13, primary ? 0 : Color.rgb(50,84,87)));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private TextView text(String content,int size,int color,boolean bold) {
        TextView v = new TextView(this);
        v.setText(content);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setLineSpacing(dp(2),1f);
        if (bold) v.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        return v;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private GradientDrawable round(int color,int radius,int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if(border != 0) d.setStroke(dp(1),border);
        return d;
    }
    private void topSpace(LinearLayout parent,int h) {
        View v = new View(this);
        parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));
    }
    private int dp(float value) {
        return (int)(value*getResources().getDisplayMetrics().density+.5f);
    }

    private void updateStatus(boolean active) {
        if(status != null) {
            status.setText(active ? "●  Ativada — somente demonstração" : "●  Desativada");
            status.setTextColor(active ? MINT : MUTED);
        }
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Permita 'Exibir sobre outros apps' e volte ao ESP Lab",Toast.LENGTH_LONG).show();
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            return;
        }
        if(Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 200);
        }
        try {
            Intent service = new Intent(this,OverlayService.class);
            startForegroundService(service);
            updateStatus(true);
        } catch (RuntimeException e) {
            updateStatus(false);
            Toast.makeText(this,"Não foi possível iniciar a sobreposição",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onResume() {
        super.onResume();
        updateStatus(OverlayService.running);
    }
}
