package br.com.esplab;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * Renders invented example actors. No game interaction, memory reading,
 * data collection, process injection or game hooking is performed.
 */
public final class EspCanvasView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences settings;
    private final boolean transparentOverlay;
    private final float density;
    private final long beginTime = System.currentTimeMillis();

    private static final float[] X = { .22f, .76f, .49f };
    private static final float[] Y = { .70f, .62f, .83f };
    private static final String[] NAMES = { "BOT_01", "BOT_02", "BOT_03" };
    private static final String[] DISTANCES = { "42m", "87m", "19m" };

    public EspCanvasView(Context context, boolean transparentOverlay) {
        super(context);
        this.transparentOverlay = transparentOverlay;
        this.settings = EspSettings.get(context);
        this.density = context.getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private void color(int rgb, int alpha) {
        paint.setColor((Math.max(0, Math.min(alpha, 255)) << 24) | (rgb & 0xFFFFFF));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setShader(null);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth(), height = getHeight();
        if (width < 5 || height < 5) return;
        float w = width, h = height;
        float t = (System.currentTimeMillis() - beginTime) / 1000f;
        int alpha = (int)(255f * settings.getInt(EspSettings.OPACITY, 90) / 100f);
        float stroke = density * settings.getInt(EspSettings.THICKNESS, 2);
        int mint = Color.rgb(66,228,191);

        if (!transparentOverlay) drawScenario(canvas, w, h);

        // Sample target locations are fictional and are independent of the pixels behind the overlay.
        for (int i = 0; i < X.length; i++) {
            float sway = (float)Math.sin(t * .75 + i * 1.7) * w * .013f;
            float cx = w * X[i] + sway;
            float feet = h * Y[i];
            float boxH = Math.min(h * .31f, w * (transparentOverlay ? .75f : .45f));
            float boxW = boxH * .40f;
            float left = cx - boxW/2f, top = feet - boxH;
            float right = cx + boxW/2f;

            if (EspSettings.read(settings, EspSettings.TRACER)) {
                color(mint, (int)(alpha * .65f)); paint.setStrokeWidth(stroke);
                canvas.drawLine(w*.5f, h*.97f, cx, feet, paint);
            }
            if (EspSettings.read(settings, EspSettings.BOX)) {
                color(mint, alpha); paint.setStrokeWidth(stroke);
                canvas.drawRoundRect(new RectF(left, top, right, feet), 4*density, 4*density, paint);
                float corner = Math.min(boxW*.2f, 10*density);
                paint.setStrokeWidth(stroke * 1.5f);
                canvas.drawLine(left, top, left+corner, top, paint);
                canvas.drawLine(right-corner, top, right, top, paint);
            }
            if (EspSettings.read(settings, EspSettings.SKELETON)) {
                color(Color.WHITE, (int)(alpha * .8f)); paint.setStrokeWidth(stroke);
                float headY = top + boxH * .16f;
                float shoulderY = top + boxH * .34f;
                float hipY = top + boxH * .64f;
                float neckY = top + boxH * .25f;
                canvas.drawCircle(cx, headY, boxW * .13f, paint);
                canvas.drawLine(cx, neckY, cx, hipY, paint);
                canvas.drawLine(cx-boxW*.28f, shoulderY, cx+boxW*.28f, shoulderY, paint);
                canvas.drawLine(cx-boxW*.28f, shoulderY, cx-boxW*.38f, top+boxH*.55f, paint);
                canvas.drawLine(cx+boxW*.28f, shoulderY, cx+boxW*.38f, top+boxH*.55f, paint);
                canvas.drawLine(cx, hipY, cx-boxW*.25f, feet-boxH*.04f, paint);
                canvas.drawLine(cx, hipY, cx+boxW*.25f, feet-boxH*.04f, paint);
            }
            if (EspSettings.read(settings, EspSettings.HEALTH)) {
                float hp = i == 1 ? .56f : (i == 0 ? .85f : 1f);
                float x = left - 7*density;
                color(Color.rgb(62,68,87), alpha); paint.setStyle(Paint.Style.FILL);
                canvas.drawRoundRect(new RectF(x-3*density, top, x, feet), 2,2,paint);
                color(Color.rgb(92,230,149), alpha); paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(x-3*density, feet-boxH*hp, x, feet, paint);
            }
            if (EspSettings.read(settings, EspSettings.NAME)) {
                label(canvas, NAMES[i], cx, top - 11*density, transparentOverlay ? 11 : 9, alpha, Color.WHITE);
            }
            if (EspSettings.read(settings, EspSettings.DISTANCE)) {
                label(canvas, DISTANCES[i], cx, feet + 13*density, transparentOverlay ? 11 : 9, alpha, mint);
            }
        }

        if (EspSettings.read(settings, EspSettings.CROSSHAIR)) {
            float cx = w*.5f, cy = h*.5f;
            float r = 7*density;
            color(Color.WHITE, alpha); paint.setStrokeWidth(Math.max(1*density, stroke*.6f));
            canvas.drawLine(cx-r-5*density,cy,cx-r/2,cy,paint);
            canvas.drawLine(cx+r/2,cy,cx+r+5*density,cy,paint);
            canvas.drawLine(cx,cy-r-5*density,cx,cy-r/2,paint);
            canvas.drawLine(cx,cy+r/2,cx,cy+r+5*density,paint);
        }
        if (transparentOverlay) {
            color(Color.rgb(7,16,29), 190); paint.setStyle(Paint.Style.FILL);
            float bw = Math.min(w-16*density, 262*density);
            canvas.drawRoundRect(new RectF((w-bw)/2, 26*density, (w+bw)/2, 53*density), 9*density,9*density,paint);
            label(canvas, "ESP LAB • DEMONSTRAÇÃO", w/2, 44*density, 11, 255, mint);
        }
        postInvalidateDelayed(80);
    }

    private void label(Canvas c, String text, float x, float y, float size, int alpha, int rgb) {
        color(rgb, alpha);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(size*density);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        paint.setTextAlign(Paint.Align.CENTER);
        c.drawText(text, x, y, paint);
    }

    private void drawScenario(Canvas canvas, float w, float h) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0,0,w,h, Color.rgb(24,38,58), Color.rgb(9,16,33), Shader.TileMode.CLAMP));
        canvas.drawRect(0,0,w,h,paint);
        paint.setShader(null);
        // Grid and horizon are part of the editor's own synthetic scene.
        color(Color.rgb(62,105,116), 45); paint.setStrokeWidth(density*.75f);
        for (int i=1;i<8;i++) canvas.drawLine(w*i/8f,0,w*i/8f,h,paint);
        for (int i=1;i<6;i++) canvas.drawLine(0,h*i/6f,w,h*i/6f,paint);
        color(Color.rgb(66,228,191), 100); paint.setStrokeWidth(density);
        canvas.drawLine(0,h*.84f,w,h*.84f,paint);
        color(Color.rgb(105,129,152), 110); paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(10*density);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("CENÁRIO SIMULADO", 14*density, 22*density, paint);
    }
}
