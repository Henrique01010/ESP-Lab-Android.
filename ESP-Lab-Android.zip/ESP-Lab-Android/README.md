# ESP Lab Android — protótipo de interface

Protótipo Android **original**, inspirado na categoria visual de menus de ESP. Desenvolvido em Java sem bibliotecas externas e sem copiar código ou recursos do APK Cry4Me Loader.

## O que funciona

- Prévia gráfica com três alvos **inventados** e uma animação simples.
- Controles para caixas, nomes, distâncias, esqueleto, linhas indicadoras, barras de vida e mira.
- Ajustes persistentes de opacidade e espessura via `SharedPreferences`.
- Sobreposição (`TYPE_APPLICATION_OVERLAY`) sobre outros aplicativos, com permissão explícita do Android.
- Notificação persistente da demonstração e botão para interromper a sobreposição.
- Compatibilidade de projeto: Android 8.0+ (`minSdk 26`), compilação para Android SDK 35; projeto sem dependência de root.

## O que NÃO faz

- Não executa o Oxide, não busca jogadores reais e não acompanha posições do jogo.
- Não possui virtualizador, loader, ESP funcional no jogo, aimbot ou modificação de aplicativos.
- Não utiliza código de terceiros, hooks, injeção, leitura de memória nem bypass de anticheat.
- As etiquetas e posições do HUD são **fixas/simuladas**; sobrepor o desenho a um jogo não o torna um ESP real.

## Compilar no PC com Android Studio

1. Instale uma versão atual do **Android Studio**, com **JDK 17** e o **Android SDK 35**.
2. Extraia o ZIP `ESP-Lab-Android.zip`.
3. No Android Studio, abra a pasta **ESP-Lab-Android** contendo `settings.gradle`.
4. Se o Android Studio pedir qual Gradle usar, escolha Gradle **8.9** (ou superior suportado pelo Android Gradle Plugin 8.7.3). O projeto não inclui o arquivo binário `gradle-wrapper.jar`, pois não havia uma distribuição Gradle disponível no ambiente de criação.
5. Sincronize o projeto e selecione **Build > Build APK(s)**. Para obter um APK de teste use a tarefa `:app:assembleDebug`.
6. Copie `app/build/outputs/apk/debug/app-debug.apk` para o celular e instale.

## Compilar na nuvem pelo GitHub Actions (sem AndroidIDE)

Este repositório inclui `.github/workflows/build-apk.yml`.

1. Crie um repositório GitHub e coloque **o conteúdo da pasta** `ESP-Lab-Android` na raiz, preservando a pasta `.github` (arquivos ocultos).
2. Abra a aba **Actions** do repositório.
3. Entre em **Compilar APK de teste** e selecione **Run workflow**; um envio para a branch `main` também dispara a compilação.
4. Após a execução, abra o job concluído e baixe o artefato `esp-lab-debug-apk`. Ele contém `app-debug.apk`.

O GitHub Action precisa de acesso à internet para obter o Gradle, Android SDK e plugin. O código entregue aqui **não foi compilado nem executado** no dispositivo.

## Testar no Android

1. Abra **ESP Lab**.
2. Alterne os controles e confira a prévia dinâmica do próprio aplicativo.
3. Se quiser uma sobreposição, toque em **Ativar sobreposição de teste**.
4. Autorize **Exibir sobre outros apps** nas configurações, volte e toque novamente.
5. Abra outro aplicativo e veja as caixas **fictícias**. Para encerrar, toque em **Desativar sobreposição** no painel ou **Parar** na notificação.

> Aviso: sobreposições podem atrapalhar aplicativos bancários ou telas sensíveis; desative quando não estiver testando. Não conceda a este projeto acesso à câmera, microfone, localização ou arquivos — ele não solicita essas permissões.

## Estrutura

```text
app/src/main/AndroidManifest.xml
app/src/main/java/br/com/esplab/MainActivity.java   # Painel nativo
app/src/main/java/br/com/esplab/EspCanvasView.java  # Desenho dos alvos simulados
app/src/main/java/br/com/esplab/EspSettings.java    # Preferências
app/src/main/java/br/com/esplab/OverlayService.java # Camada de teste
.github/workflows/build-apk.yml                     # Gera APK debug no GitHub
```

## Desenvolvimento futuro

É possível integrar o renderer a um **jogo próprio** ou ambiente de testes com uma API de posições de objetos que você controle, preservando a separação entre a camada visual e a fonte de dados.
